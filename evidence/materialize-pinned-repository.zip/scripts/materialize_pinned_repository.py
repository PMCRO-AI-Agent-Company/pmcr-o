from __future__ import annotations
import argparse, hashlib, json, os, pathlib, re, shutil, subprocess, tempfile, urllib.parse, zipfile

HEX40 = re.compile(r"^[0-9a-fA-F]{40}$")

def fail(msg: str) -> None:
    raise SystemExit(msg)

def inside(root: pathlib.Path, child: pathlib.Path) -> bool:
    try:
        child.relative_to(root)
        return child != root
    except ValueError:
        return False

def validate(args):
    if shutil.which("git") is None:
        fail("git-runtime-required")
    if not HEX40.fullmatch(args.commit or ""):
        fail("exact-40-hex-commit-required")
    u = urllib.parse.urlsplit(args.repository)
    if u.scheme.lower() != "https" or not u.netloc or u.username or u.password:
        fail("credential-free-https-repository-required")
    root = pathlib.Path(args.workspace_root).resolve()
    dest = pathlib.Path(args.destination).resolve()
    receipt = pathlib.Path(args.receipt).resolve()
    if not root.is_absolute() or not dest.is_absolute() or not receipt.is_absolute():
        fail("absolute-paths-required")
    if not inside(root, dest) or not inside(root, receipt):
        fail("workspace-boundary-required")
    if args.mode in {"preflight", "simulate", "execute"} and dest.exists():
        fail("destination-must-not-exist")
    return root, dest, receipt

def run(cmd, cwd=None):
    cp = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if cp.returncode:
        fail(f"git-command-failed:{cp.returncode}:{cp.stderr.strip()}")
    return cp.stdout.strip()

def manifest(dest: pathlib.Path):
    rows=[]
    for p in sorted((p for p in dest.rglob("*") if p.is_file()), key=lambda p:p.relative_to(dest).as_posix()):
        rel=p.relative_to(dest).as_posix()
        rows.append({"path":rel,"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"size":p.stat().st_size})
    canonical="\n".join(f"{x['path']}={x['sha256']}" for x in rows).encode()
    return rows, hashlib.sha256(canonical).hexdigest()

def atomic_json(path: pathlib.Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+".tmp")
    tmp.write_text(json.dumps(obj, indent=2)+"\n", encoding="utf-8")
    os.replace(tmp, path)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["preflight","simulate","execute","check"], default="preflight")
    ap.add_argument("--repository", required=True)
    ap.add_argument("--commit", required=True)
    ap.add_argument("--workspace-root", required=True)
    ap.add_argument("--destination", required=True)
    ap.add_argument("--receipt", required=True)
    args=ap.parse_args()
    root,dest,receipt=validate(args)
    plan=["git init --bare <temp>",f"git fetch --depth=1 --no-tags {args.repository} {args.commit}","verify FETCH_HEAD == requested commit","reject gitlinks/submodules","git archive --format=zip <commit>",f"extract new snapshot -> {dest}",f"write atomic receipt -> {receipt}"]
    if args.mode in {"preflight","simulate"}:
        print(json.dumps({"ok":True,"mode":args.mode,"repository":args.repository,"commit":args.commit.lower(),"destination":str(dest),"plannedOperations":plan if args.mode=="simulate" else [],"authorityConferred":False},indent=2)); return
    if args.mode=="check":
        if not dest.is_dir() or not receipt.is_file(): fail("snapshot-or-receipt-missing")
        data=json.loads(receipt.read_text(encoding="utf-8-sig"))
        rows,digest=manifest(dest)
        ok=(data.get("repository")==args.repository and str(data.get("commit","")).lower()==args.commit.lower() and data.get("manifestDigest")==digest and data.get("fileCount")==len(rows))
        if not ok: fail("materialization-check-failed")
        print(json.dumps({"ok":True,"mode":"check","commit":args.commit.lower(),"fileCount":len(rows),"manifestDigest":digest,"authorityConferred":False},indent=2)); return
    root.mkdir(parents=True, exist_ok=True)
    work=pathlib.Path(tempfile.mkdtemp(prefix="pmcro-git-", dir=root))
    archive=work/"source.zip"
    bare=work/"repo.git"
    try:
        run(["git","init","--bare",str(bare)])
        run(["git","--git-dir",str(bare),"fetch","--depth=1","--no-tags",args.repository,args.commit])
        got=run(["git","--git-dir",str(bare),"rev-parse","FETCH_HEAD"]).lower()
        if got!=args.commit.lower(): fail("fetched-commit-mismatch")
        tree=run(["git","--git-dir",str(bare),"ls-tree","-r",got])
        if any(line.startswith("160000 ") for line in tree.splitlines()): fail("submodules-not-supported")
        run(["git","--git-dir",str(bare),"archive","--format=zip",f"--output={archive}",got])
        dest.mkdir(parents=True, exist_ok=False)
        with zipfile.ZipFile(archive) as z: z.extractall(dest)
        rows,digest=manifest(dest)
        data={"apiVersion":"pmcro.source-materialization/v1","kind":"PinnedRepositorySnapshot","repository":args.repository,"commit":got,"destination":str(dest),"fileCount":len(rows),"manifestDigest":digest,"authorityConferred":False,"registered":False,"granted":False,"activated":False,"invoked":False}
        atomic_json(receipt,data)
        print(json.dumps({"ok":True,"mode":"execute",**data},indent=2))
    except BaseException:
        if dest.exists() and not receipt.exists(): shutil.rmtree(dest, ignore_errors=True)
        raise
    finally:
        shutil.rmtree(work, ignore_errors=True)

if __name__=="__main__": main()
