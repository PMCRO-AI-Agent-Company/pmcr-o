---
name: materialize-pinned-repository
description: "Materialize one exact Git commit as an immutable source snapshot using native Git and PMCR-O evidence boundaries."
---
---
name: materialize-pinned-repository
description: "Materialize one exact Git commit into an immutable source snapshot using native Git, without branch/tag authority, credentials, overwrite, or submodule execution."
---
# materialize-pinned-repository

Use this skill when a checked marketplace/import plan needs local source bytes from an exact Git repository commit.

## Progressive disclosure

1. Read `references/contract.md`.
2. Run `scripts/materialize_pinned_repository.py --help`.
3. Run `--mode preflight` to validate Git, repository URL, exact 40-hex commit, workspace boundary, and destination state.
4. Run `--mode simulate` to emit the native Git operations without network or filesystem mutation.
5. Execute only under the owning Trail's applicable grant.
6. Run `--mode check` against the materialized snapshot and its receipt.
7. Return receipt/hash evidence to the owning Trail and independent Checker.

## Native-first implementation

The script delegates repository semantics to native `git`. It does not implement a Git client, branch resolver, package installer, or credential manager.

## Boundaries

- Commit must be an exact 40-character SHA-1 object id; branch/tag names are rejected.
- Repository URL must be HTTPS and must not contain user-info/credentials.
- Destination must be absent before execute and remain under the declared workspace root.
- Existing destinations are never overwritten or refreshed.
- Git submodules are rejected rather than initialized.
- The materialized snapshot contains source files only; `.git` is not projected into it.
- Source acquisition does not register, grant, activate, publish, invoke, or execute imported capabilities.
- A successful materialization is evidence, not runtime authority.
