# Pinned repository materialization contract

Input:
- repository: HTTPS Git repository URL with no user-info/credentials.
- commit: exact 40-hex Git commit object id.
- workspace-root: absolute authorized workspace/candidate root.
- destination: absolute path strictly under workspace-root.
- receipt: absolute evidence JSON path strictly under workspace-root, outside destination when practical.

Modes:
- preflight: local validation only; no network, no mutation.
- simulate: local validation + exact planned native Git operations; no network, no mutation.
- execute: native Git fetch/archive of only the exact commit into a new destination, then write receipt atomically.
- check: recompute the snapshot manifest digest and verify receipt/source binding; no mutation.

Execution algorithm:
1. Create a temporary bare repository under workspace-root.
2. `git init --bare`.
3. `git fetch --depth=1 --no-tags <repository> <exact-commit>`.
4. Verify `FETCH_HEAD` equals the requested commit.
5. Reject any gitlink/submodule entries (`160000`).
6. `git archive --format=zip` the exact commit.
7. Expand into a destination that did not previously exist.
8. Hash every source file using normalized root-relative `/` paths and SHA-256.
9. Write an atomic receipt binding repository, commit, file count, and manifest digest.
10. Delete temporary Git state/archive.

Security/lifecycle:
- No credential discovery/export.
- No branch/tag resolution.
- No checkout into an existing workspace.
- No hooks/submodules/LFS execution.
- No registration/grant/activation/use authority.
