# PMCR-O command discovery

Read contracts.json for each command's intent, inputs, output and lifecycle boundary.
Human route: `@orchestrator /pmcro:<command>`. Role progress: `@<role> /pmcro:<phase>`.
Optional notes/context references remain data. Runtime bindings in `.pmcro` are separate and unchanged by authoring.
Commands do not establish registration or invoke a newly authored candidate.
