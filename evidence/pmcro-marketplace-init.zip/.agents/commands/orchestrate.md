# /pmcro:orchestrate

Canonical route: `@orchestrator /pmcro:orchestrate`. Active role updates use `@<role> /pmcro:orchestrate`.

Intent: Admit, reject, defer, or supersede a Seed for a declared Agent.

Required inputs: intent, agentRef.
Optional notes and contextRefs explain the request; they never advance a phase or widen authority.
Resolve references through the governing runtime before operational use. Do not fabricate missing Trail/Cycle/Frame identities.
This file declares the command contract only. See `contracts.json` and `request.schema.json`.
