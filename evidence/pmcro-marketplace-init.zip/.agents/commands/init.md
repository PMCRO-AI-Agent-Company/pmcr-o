# /pmcro:init

Canonical route: `@orchestrator /pmcro:init`. Active role updates use `@<role> /pmcro:init`.

Intent: Materialize provider-neutral project context without runtime state.

Required inputs: intent, agentRef.
Optional notes and contextRefs explain the request; they never advance a phase or widen authority.
Resolve references through the governing runtime before operational use. Do not fabricate missing Trail/Cycle/Frame identities.
This file declares the command contract only. See `contracts.json` and `request.schema.json`.
