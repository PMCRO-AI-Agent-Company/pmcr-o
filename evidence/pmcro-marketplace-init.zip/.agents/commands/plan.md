# /pmcro:plan

Canonical route: `@orchestrator /pmcro:plan`. Active role updates use `@<role> /pmcro:plan`.

Intent: Define acceptance criteria and bounded steps for admitted intent.

Required inputs: intent, agentRef, cycleRef.
Optional notes and contextRefs explain the request; they never advance a phase or widen authority.
Resolve references through the governing runtime before operational use. Do not fabricate missing Trail/Cycle/Frame identities.
This file declares the command contract only. See `contracts.json` and `request.schema.json`.
