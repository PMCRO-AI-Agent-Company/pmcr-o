# /pmcro:reflect

Canonical route: `@orchestrator /pmcro:reflect`. Active role updates use `@<role> /pmcro:reflect`.

Intent: Record the verified outcome and exactly one unexecuted next intent.

Required inputs: intent, agentRef, cycleRef.
Optional notes and contextRefs explain the request; they never advance a phase or widen authority.
Resolve references through the governing runtime before operational use. Do not fabricate missing Trail/Cycle/Frame identities.
This file declares the command contract only. See `contracts.json` and `request.schema.json`.
