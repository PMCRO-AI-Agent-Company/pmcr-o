# agent-memory

Reserved provider-neutral context. Presence grants no authority.
