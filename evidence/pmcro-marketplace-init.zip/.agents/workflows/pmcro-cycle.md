# PMCR-O Cycle Workflow

Seed ingress is admitted outside cognition. A Cycle begins only at ORCHESTRATE.

1. ORCHESTRATE
2. PLAN
3. MAKE
4. CHECK
5. REFLECT

Every Agent may execute the same five cognitive phases within its own bounded Agent-owned Trail. Child Trails retain `rootTrailId` and `parentTrailId`; child Cycles retain `rootCycleId` and `parentCycleId` when applicable.

A reflected NextSeedIntent returns as data and is never automatically executed.

<!-- PMCR-O-TRAIL-LAW:v3 -->
## PMCR-O Trail law

- Preserve messy external input as the raw Seed.
- No active Trail: `@orchestrator /pmcro:init "<messy intent>"`.
- Active Trail: `@orchestrator /pmcro:seed "<messy intent>"`.
- `/pmcro:seed` is ingress, not approval. Accept, reject, defer, and supersede are internal Orchestrator decisions.
- Run ORCHESTRATE -> PLAN -> MAKE -> CHECK -> REFLECT to turn the messy Seed into evidence-backed True Intent.
- `SEED != TRUE INTENT` and `TRUE INTENT != AUTHORITY`.
- When True Intent selects another domain agent that needs its own context, call `@[agent] /init "<true intent>"` to open its child/domain Trail. `INIT != AUTHORITY`.
- Discover the smallest marketplace -> plugin -> skill path using progressive disclosure.
- `DISCOVERY != REGISTRATION != GRANT != ACTIVATION != EXECUTION`.
- Triggers, schedules, GitHub Actions, queue messages, MCP events, executive recommendations, and child Trails may propose work but never grant authority.
- Every mutating action must re-enter PMCR-O admission, pass its verified grant boundary, and receive independent Checker evidence.
- `CHILD TRAILS RETURN EVIDENCE, NOT AUTHORITY`.
- `EVERY ACTION RETURNS TO A TRAIL` with evidence or an ActionReceipt.
- User-facing `SendMessage` updates should be short and text-to-speech friendly: visible identity, plain-language status, and what happens next. The structured Trail keeps IDs, causation, correlation, evidence refs, and authority state underneath.

