# PMCR-O Laws

- Exactly five cognitive phases: ORCHESTRATE -> PLAN -> MAKE -> CHECK -> REFLECT.
- INIT is bootstrap, not a cognitive phase.
- Seed ingress is not a Frame.
- MESSAGE ARRIVAL != PHASE TRANSITION.
- DISCOVERABLE != REGISTERED != GRANTED != INVOKABLE != EXECUTED.
- CONTEXT != AUTHORITY. PROJECTION != AUTHORITY. HOST != AUTHORITY.
- Missing functionality is created as a capability, checked independently, then registered before later use.
- CREATE and USE are separate lifecycle events.
- Descendant specialization never widens authority.

<!-- PMCR-O-TRAIL-LAW:v3 -->
## PMCR-O Trail law

- Preserve messy external input as the raw Seed.
- No active Trail: `@orchestrator /pmcro:init "<messy intent>"`.
- Active Trail: `@orchestrator /pmcro:seed "<messy intent>"`.
- `/pmcro:seed` is ingress, not approval. Accept, reject, defer, and supersede are internal Orchestrator decisions.
- Run ORCHESTRATE -> PLAN -> MAKE -> CHECK -> REFLECT to turn the messy Seed into evidence-backed True Intent.
- `SEED != TRUE INTENT` and `TRUE INTENT != AUTHORITY`.
- When True Intent selects another domain agent that needs its own context, call `@[agent] /init "<true intent>"` to open its child/domain Trail. `INIT != AUTHORITY`.
- Discover the smallest marketplace -> plugin -> skill path using progressive disclosure.
- `DISCOVERY != REGISTRATION != GRANT != ACTIVATION != EXECUTION`.
- Triggers, schedules, GitHub Actions, queue messages, MCP events, executive recommendations, and child Trails may propose work but never grant authority.
- Every mutating action must re-enter PMCR-O admission, pass its verified grant boundary, and receive independent Checker evidence.
- `CHILD TRAILS RETURN EVIDENCE, NOT AUTHORITY`.
- `EVERY ACTION RETURNS TO A TRAIL` with evidence or an ActionReceipt.
- User-facing `SendMessage` updates should be short and text-to-speech friendly: visible identity, plain-language status, and what happens next. The structured Trail keeps IDs, causation, correlation, evidence refs, and authority state underneath.

