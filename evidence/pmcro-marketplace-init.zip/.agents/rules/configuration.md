# Provider-neutral Configuration

Use Claude-style scopes without making any provider the authority:

1. User defaults: `~/.agents/settings.json` — personal defaults across projects on the machine.
2. Shared Project: `.agents/settings.json` — portable team/project configuration.
3. Project local: `.agents/settings.local.json` — machine-local overrides; keep out of source control.
4. Session/host override: supplied by the active host adapter for one session only.
5. Managed policy: organization/runtime enforcement when a host supports it.

Resolution precedence for ordinary configuration is `managed -> session -> project-local -> project -> user`.

Configuration never widens PMCR-O authority. Effective execution remains bounded by explicit grants, host maximums, environment maximums, and denies.

Host-specific values such as model identifiers, native tool names, provider hooks, or transport details belong in host projections/overrides unless they are intentionally portable.

<!-- PMCR-O-TRAIL-LAW:v3 -->
## PMCR-O Trail law

- Preserve messy external input as the raw Seed.
- No active Trail: `@orchestrator /pmcro:init "<messy intent>"`.
- Active Trail: `@orchestrator /pmcro:seed "<messy intent>"`.
- `/pmcro:seed` is ingress, not approval. Accept, reject, defer, and supersede are internal Orchestrator decisions.
- Run ORCHESTRATE -> PLAN -> MAKE -> CHECK -> REFLECT to turn the messy Seed into evidence-backed True Intent.
- `SEED != TRUE INTENT` and `TRUE INTENT != AUTHORITY`.
- When True Intent selects another domain agent that needs its own context, call `@[agent] /init "<true intent>"` to open its child/domain Trail. `INIT != AUTHORITY`.
- Discover the smallest marketplace -> plugin -> skill path using progressive disclosure.
- `DISCOVERY != REGISTRATION != GRANT != ACTIVATION != EXECUTION`.
- Triggers, schedules, GitHub Actions, queue messages, MCP events, executive recommendations, and child Trails may propose work but never grant authority.
- Every mutating action must re-enter PMCR-O admission, pass its verified grant boundary, and receive independent Checker evidence.
- `CHILD TRAILS RETURN EVIDENCE, NOT AUTHORITY`.
- `EVERY ACTION RETURNS TO A TRAIL` with evidence or an ActionReceipt.
- User-facing `SendMessage` updates should be short and text-to-speech friendly: visible identity, plain-language status, and what happens next. The structured Trail keeps IDs, causation, correlation, evidence refs, and authority state underneath.

