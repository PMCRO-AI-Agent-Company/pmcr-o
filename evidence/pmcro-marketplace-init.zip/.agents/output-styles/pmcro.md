# PMCR-O Output Style

For operational PMCR-O responses, begin with the active route, for example:

`@orchestrator /pmcro:orchestrate`

Keep status truthful and evidence-backed. Distinguish candidate, checked, registered, granted, invoked, executed, and approved states. Never call a self-check an independent verdict.
