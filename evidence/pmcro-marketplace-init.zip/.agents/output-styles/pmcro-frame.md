# PMCR-O Frame Output

Prefer a machine-readable envelope with:

`frameId`, `trailId`, `cycleId`, `seq`, `role`, `phase`, `parentId`, `prevHash`, `hash`, `status`, `payload`.

Role identity and cognitive phase are separate fields.
