using AgentGovernance.Trust;

namespace ProjectName.Runtime.Maf;

/// <summary>
/// Thin PMCR-O semantic adapter over Agent Governance Toolkit identity/capability primitives.
/// AGT owns capability narrowing, delegation-chain validation, trust and cascade revocation.
/// This type does not create a second grant algorithm.
/// </summary>
public sealed class AgtNativeCapabilityAuthority
{
    private readonly IdentityRegistry registry;

    public AgtNativeCapabilityAuthority(bool requireAttestation = false)
    {
        registry = new IdentityRegistry(requireAttestation);
    }

    public int Count => registry.Count;

    public AgentIdentity RegisterRoot(
        string name,
        string sponsor,
        IEnumerable<string> capabilities,
        bool sponsorVerified = false,
        bool attestationVerified = false)
    {
        var identity = AgentIdentity.CreateAsymmetric(
            name: name,
            sponsor: sponsor,
            capabilities: capabilities,
            sponsorVerified: sponsorVerified,
            attestationVerified: attestationVerified);
        registry.Register(identity);
        return identity;
    }

    public AgentIdentity Register(AgentIdentity identity)
    {
        ArgumentNullException.ThrowIfNull(identity);
        registry.Register(identity);
        return identity;
    }

    public AgentIdentity Delegate(
        string parentDid,
        string childName,
        IEnumerable<string> requestedCapabilities,
        string? description = null)
    {
        var parent = registry.Get(parentDid);
        if (!registry.IsTrusted(parent.Did))
            throw new UnauthorizedAccessException("agt-parent-identity-not-trusted");

        var child = parent.Delegate(childName, requestedCapabilities, description);
        registry.Register(child);

        if (!AgentIdentity.VerifyDelegationChain(child, registry))
            throw new UnauthorizedAccessException("agt-delegation-chain-invalid");

        return child;
    }

    public IReadOnlySet<string> GetEffectiveCapabilities(string did)
    {
        var identity = registry.Get(did);
        if (!registry.IsTrusted(identity.Did))
            return new HashSet<string>(StringComparer.Ordinal);

        return identity.GetEffectiveCapabilities(registry).ToHashSet(StringComparer.Ordinal);
    }

    public bool Allows(string did, string capability)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(capability);
        return GetEffectiveCapabilities(did).Contains(capability);
    }

    public void Revoke(string did, string reason) => registry.Revoke(did, reason);

    public bool IsTrusted(string did) => registry.IsTrusted(did);
}