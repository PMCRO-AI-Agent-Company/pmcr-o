using AgentGovernance.Extensions.ModelContextProtocol;
using AgentGovernance.Policy;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ModelContextProtocol.Protocol;
using ProjectName.Harness;
using ProjectName.Tooling;

var builder = Host.CreateApplicationBuilder(args);
var mcpPolicyPath = Path.Combine(AppContext.BaseDirectory, "policies", "mcp.yaml");
builder.Services.AddProjectNameAgentSystem();
builder.Services.AddSingleton<IMcpOperationEligibility, DefaultMcpOperationEligibility>();
builder.Services.AddSingleton<DynamicPmcroMcpProjection>();

builder.Services
    .AddMcpServer()
    .WithGovernance(options =>
    {
        options.PolicyPaths.Add(mcpPolicyPath);
        options.ConflictStrategy = ConflictResolutionStrategy.DenyOverrides;
        options.EnableAudit = true;
        options.EnableMetrics = true;
        options.RequireAuthenticatedAgentId = false;
        options.DefaultAgentId = "did:mcp:pmcro-local-stdio";
        options.ServerName = "pmcro-agent-system";
        options.FailOnUnsafeTools = true;
        options.SanitizeResponses = true;
        options.GovernFallbackHandlers = true;
    })
    .WithStdioServerTransport()
    .WithListToolsHandler((request, cancellationToken) =>
    {
        var services = request.Services ?? throw new InvalidOperationException("mcp-request-services-required");
        var projection = services.GetRequiredService<DynamicPmcroMcpProjection>();
        return ValueTask.FromResult(new ListToolsResult { Tools = projection.ListTools().ToList() });
    })
    .WithCallToolHandler((request, cancellationToken) =>
    {
        var services = request.Services ?? throw new InvalidOperationException("mcp-request-services-required");
        var projection = services.GetRequiredService<DynamicPmcroMcpProjection>();
        return ValueTask.FromResult(projection.Call(request.Params));
    });

await builder.Build().RunAsync();