using ProjectName.Runtime.Maf;
using Xunit;

namespace ProjectName.Runtime.Tests;

public sealed class AgtNativeGovernanceTests
{
    [Fact]
    public void Delegation_is_native_and_monotonic()
    {
        var authority = new AgtNativeCapabilityAuthority();
        var root = authority.RegisterRoot(
            "pmcro-owner",
            "owner@example.invalid",
            new[] { "github.recover-account-access:inspect", "github.recover-account-access:check", "capability.invoke" });

        var child = authority.Delegate(
            root.Did,
            "github-recovery",
            new[] { "github.recover-account-access:inspect", "github.recover-account-access:check" });

        var effective = authority.GetEffectiveCapabilities(child.Did);
        Assert.Equal(
            new[] { "github.recover-account-access:check", "github.recover-account-access:inspect" },
            effective.OrderBy(x => x, StringComparer.Ordinal));
        Assert.False(authority.Allows(child.Did, "capability.invoke"));
        Assert.Throws<InvalidOperationException>(() => authority.Delegate(
            root.Did,
            "illegal-expansion",
            new[] { "github.repo.write" }));
    }

    [Fact]
    public void Registry_revocation_cascades_to_delegated_identity()
    {
        var authority = new AgtNativeCapabilityAuthority();
        var root = authority.RegisterRoot(
            "pmcro-owner",
            "owner@example.invalid",
            new[] { "github.recover-account-access:inspect" });
        var child = authority.Delegate(
            root.Did,
            "github-recovery",
            new[] { "github.recover-account-access:inspect" });

        Assert.True(authority.IsTrusted(root.Did));
        Assert.True(authority.IsTrusted(child.Did));

        authority.Revoke(root.Did, "test-revocation");

        Assert.False(authority.IsTrusted(root.Did));
        Assert.False(authority.IsTrusted(child.Did));
        Assert.Empty(authority.GetEffectiveCapabilities(child.Did));
    }
}