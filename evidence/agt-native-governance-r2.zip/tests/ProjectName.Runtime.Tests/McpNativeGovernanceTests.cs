using AgentGovernance;
using AgentGovernance.Policy;
using Xunit;

namespace ProjectName.Runtime.Tests;

public sealed class McpNativeGovernanceTests
{
    [Fact]
    public void Native_mcp_policy_is_deny_by_default_and_emits_audit_events()
    {
        var root = FindSolutionRoot();
        var policy = Path.Combine(root, "src", "ProjectName.McpServer", "policies", "mcp.yaml");
        Assert.True(File.Exists(policy));

        var kernel = new GovernanceKernel(new GovernanceOptions
        {
            PolicyPaths = new() { policy },
            ConflictStrategy = ConflictResolutionStrategy.DenyOverrides,
            EnableAudit = true,
        });

        var eventCount = 0;
        kernel.OnAllEvents(_ => Interlocked.Increment(ref eventCount));

        var allowed = kernel.EvaluateToolCall("did:mcp:pmcro-local-stdio", "pmcro_commands", null);
        var denied = kernel.EvaluateToolCall("did:mcp:pmcro-local-stdio", "pmcro_write", null);

        Assert.True(allowed.Allowed);
        Assert.False(denied.Allowed);
        Assert.True(eventCount >= 2);
    }

    [Fact]
    public void Mcp_server_uses_official_agt_extension_and_explicit_stdio_identity_fallback()
    {
        var root = FindSolutionRoot();
        var program = File.ReadAllText(Path.Combine(root, "src", "ProjectName.McpServer", "Program.cs"));
        var project = File.ReadAllText(Path.Combine(root, "src", "ProjectName.McpServer", "ProjectName.McpServer.csproj"));

        Assert.Contains(".WithGovernance(options =>", program, StringComparison.Ordinal);
        Assert.Contains("RequireAuthenticatedAgentId = false", program, StringComparison.Ordinal);
        Assert.Contains("did:mcp:pmcro-local-stdio", program, StringComparison.Ordinal);
        Assert.Contains("Microsoft.AgentGovernance.Extensions.ModelContextProtocol", project, StringComparison.Ordinal);
    }

    private static string FindSolutionRoot()
    {
        var current = new DirectoryInfo(AppContext.BaseDirectory);
        while (current is not null)
        {
            if (File.Exists(Path.Combine(current.FullName, "ProjectName.slnx"))) return current.FullName;
            current = current.Parent;
        }

        throw new DirectoryNotFoundException("solution-root-not-found");
    }
}
